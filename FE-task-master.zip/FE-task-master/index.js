var li;
var tagList = document.getElementById("tag-list"); //get the list
$( document ).ready(function() { // add red,blue and purple to the list
	document.getElementById('date').innerHTML = new Date().toDateString();  //get date of today
	tagList.appendChild(createTagItem("red",""));
	tagList.appendChild(createTagItem("blue",""));
	tagList.appendChild(createTagItem("purple",""));
	firstList =["red","blue","purple"];
	history.replaceState(null, null, document.location.pathname + '#tags=' + firstList.join()); //modify the link with new tags
});

function findTagValues() { //find tag values in url
	let regGroup = window.location.hash.match(/#tags=(.+)/) //check whether url has '#tags'
	if (regGroup) { //if there are tags split them with comma
	  return regGroup[1].split(",");
	}
	return []; //else
}

function createTagItem(value, index) { //create li items
  let li = document.createElement("li");
  li.setAttribute('id', value + index); //set attributes of list item
  li.onclick = function () {
	$('#' + value + index).remove() //when click on list item remove it
	
	//find remained tags from url
	let tagValues = findTagValues(); 
	tagValues = tagValues.filter(el => el !== $(this).text())
	
	if (tagValues.length !== 0) {
	  history.replaceState(null, null, document.location.pathname + '#tags=' + tagValues.join()); //modify url
	} else {
	  history.replaceState(null, null, document.location.pathname); //modify url
	}
  };
  li.appendChild(document.createTextNode(value));
  return li;
}

function manipulateContentBasedOnHash() { //event listener
	tagList.innerHTML = ""; 
	const tagValues = findTagValues(); 
	tagValues.forEach(function (value, index) {
	  tagList.appendChild(createTagItem(value, index)); 
	});
}

function addTagItem() { // add new tag
	const tagValues = findTagValues(); //find tag values in url
	newVal = $("#input-value").val(); //get new tag from input
	if(tagValues.includes(newVal)){ //if the tag is added before
		window.confirm('This item is added before! Enter new tag...');
	}
	else if(newVal==""){ // if new tag is null
		window.confirm('You cannot enter null tag!');
	}
	else{
		tagList.appendChild(createTagItem(newVal, $('ul#tag-list li').length)); //add new tag to the list
		$("#input-value").val(""); // remove input val
		if (tagValues.length === 0) { //if the tag is new in the list add '#tags:' to url
			history.replaceState(null, null, document.location.pathname + '#tags=' + newVal);
		} else { //if not add new tag to url
			history.replaceState(null, null, document.location.pathname + window.location.hash + ',' + newVal);
		}
	}
}

//event listener
window.addEventListener('hashchange', function () {
	manipulateContentBasedOnHash();
});

	manipulateContentBasedOnHash();